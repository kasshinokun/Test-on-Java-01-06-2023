package Aula_11;

import java.util.*;

public class Principal {

	public static void main(String[] args) {
		
	int M=16;//Variavel para tamanho
        
        int[] Teste = new int[M];//Instancia vetor de inteiros de tamanho M
        Dados i =new Dados(Teste);//instancia o primeiro vetor do tipo dados
        
        i.GerarArray(M);//Envia e criar valores para as posições de modo aleatorio
        
        i.ImprimirArray();//Exibe o Array
        
        System.out.println("\nArray Exibindo em Heap : ");//Enunciado
        
        i.Heap();//Constroi e Exibe o Array em Heap
        
        boolean resp=i.CheckHeap();//Analisa o array
        
        System.out.println("\nO Array analisado se trata de uma Heap Invertida: "+resp+"\n");//Enunciado
        
        i.Heap_Sort();//em desenvolviumento
        
        //HeapSort.main(args);//Main do HeapSort
        
    }
        
}
