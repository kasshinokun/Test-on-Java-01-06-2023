package Sort;

public class QuickSort {

}
