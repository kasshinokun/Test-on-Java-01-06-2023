package preview_aula_13;

import java.util.*;//simplificação de Bibliotecas 

public class Lista_Dupla {
    
}
