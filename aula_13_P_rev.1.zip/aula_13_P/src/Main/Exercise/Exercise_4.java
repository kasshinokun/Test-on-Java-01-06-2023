package Main.Exercise;//Nome do Subprojeto
import java.util.*;//Simplificação de bibliotecas necessarias 
import TAF.*;//Package com as TAD Flexiveis
public class Exercise_4 {
    public static Scanner reader=new Scanner(System.in);
    //Objeto Scanner para Entrada global do teclado
    public static void main(String[] args){}//Em desenvolvimento
    private static void letra_A(){}
    private static void letra_B(){}
    private static void letra_C(){}
    private static void letra_D(){}
}
