package Main.Exercise;//Nome do Subprojeto
import java.util.*;//Simplificação de bibliotecas necessarias 
import TAF.*;//Package com as TAD Flexiveis
import TAF.BST.*;//Package com as Arvores Binarias
public class Exercise_2 {
    public static Scanner reader=new Scanner(System.in);
    //Objeto Scanner para Entrada global do teclado
    public static void main(String[] args){//Em desenvolvimento
        System.out.println("===02 - Gestao de Arvore de Arvore de Listas=");//Enunciado
        T_Strings Arvore=new T_Strings();
        
        Arvore.inserir("Manoel");
        Arvore.inserir("Maria");
        Arvore.inserir("Marcos");
        
        Arvore.mostrar();//Analisar codigo na classe
    
    }
    private static void letra_A(){}
    private static void letra_B(){}
    private static void letra_C(){}
    private static void letra_D(){
        
    
    }
    
    
}
