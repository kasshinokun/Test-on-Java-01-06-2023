package Act_25_04;
import java.util.*;

public class Pilha {//declaração da classe
    String[] pilha;//Vetor de Strings para a Pilha
    int [] pilha2;//Vetor de Inteiros para a Pilha
    int n=0;//Variavel para analise da Pilha
 
    public Pilha(){//Construtor default
        pilha =new String[6];//Instancia uma Pilha de String de tamanho 6
        pilha2 =new int[6];//Instancia uma Pilha de Inteiros de tamanho 6
    }
    public Pilha(int tamanho){//Sobrecarga
        pilha =new String[tamanho];
        pilha2 =new int[tamanho];
    }
    public void Exibir_Pilha(){
    
    }
}
