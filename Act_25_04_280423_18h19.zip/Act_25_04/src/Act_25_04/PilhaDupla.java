
package Act_25_04;

import java.util.*;
public class PilhaDupla {
    
    int []Array;
    
    int i=0;
    int j=0;

    PilhaDupla(){//Construtor default
        this(12);//Instancia uma Pilha de String de tamanho 6
    }
    PilhaDupla(int tamanho){//Construtor default
        Array =new int[tamanho];//Instancia um Array para Alocação das pilhas  
    }
    //Variavel global para entrada do teclado
    public static Scanner reader = new Scanner(System.in);
    
    public void Empilhar1(int p1){//Adição de Strings ao vetor
        if(i>=Array.length/2){//Se n igual ou maior que o tamanho da pilha....
        	//Informa ao Usuario
        	System.out.println("\n========Nao e possivel========");
        	System.out.println("========inserir dados,========");
        	System.out.println("========Pilha Cheia===========\n");
        }else{//senao....
            Array[(Array.length/2-1)-i]=p1;//Atribui o valor de s a posição na pilha
            i++;//incrementa i
        }
    }
     public int Desempilhar1(){//Remoção de Strings ao vetor
        int resp;//Variavel de Retorno
        if(i==0){//Se n igual a zero....
        	//Informa ao Usuario
        	System.out.println("\n========Nao e possivel========");
        	System.out.println("========remover dados,========");
        	System.out.println("========Pilha Vazia===========\n");
        	return -1;//Retorna a resp a String "Vazio"
        }else{//senao....
            resp=Array[(Array.length/2-1)-i];//resp recebe o valor da posição na pilha
            i--;//decrementa N
            return resp;//Retorna a resp ao Main
        }
    }
    public void Empilhar2(int p2){//Adição de Strings ao vetor
        if(j>=Array.length/2){//Se n igual ou maior que o tamanho da pilha....
        	//Informa ao Usuario
        	System.out.println("\n========Nao e possivel========");
        	System.out.println("========inserir dados,========");
        	System.out.println("========Pilha Cheia===========\n");
        }else{//senao....
            Array[Array.length/2+j]=p2;//Atribui o valor de s a posição na pilha
            j++;//incrementa i
        }
    
    }
     public int Desempilhar2(){//Remoção de Strings ao vetor
        int resp;//Variavel de Retorno
        if(j==0){//Se n igual a zero....
        	//Informa ao Usuario
        	System.out.println("\n========Nao e possivel========");
        	System.out.println("========remover dados,========");
        	System.out.println("========Pilha Vazia===========\n");
        	return -1;//Retorna a resp a String "Vazio"
        }else{//senao....
            resp=Array[Array.length/2+j-1];//resp recebe o valor da posição na pilha
            j--;//decrementa N
            return resp;//Retorna a resp ao Main
        }
    }
    public void Mostrar1(){//Mostra a pilha do topo a base
        for(int k=0;k<Array.length/2-1;k++){
            System.out.println(Array[k]);//Exibe a string na posição
        }
    }
    public void Mostrar2(){//Mostra a pilha do topo a base
        for(int k=Array.length;k>Array.length/2;k--){
            System.out.println(Array[k]);//Exibe a string na posição
        }
    }
    public static void main(PilhaDupla P1){
        
        System.out.println("\n==04 - Gestao de Pilha Dupla em um Array===\n");//Enunciado
        
        //0- Inicializar Pilhas(Está no Main do Codigo Principal)
        IsEmpty(P1);//Verificação se Pilhas estão vazias
        Add(P1);//2-Inserção nas Plihas
        RemoveDual(P1);//3-Remoção nas Plihas 
        PrintDual(P1);//4-Impressão das Plihas 
        
        System.out.println("\n=========Retornando ao Menu Inicial========\n");//Enunciado
    }
    public static void IsEmpty(PilhaDupla P1){//Procedimento de Verificar se Pilhas estão vazias
        System.out.println("======Verificacao das Plihas=======");//Enunciado
    }
    public static void Add(PilhaDupla P1){//Procedimento para Inserção nas Plihas
        System.out.println("=======Insercao nas Plihas=========");//Enunciado
        int value;
        int op=1;
        System.out.println("==============Pilha 1==============");//Enunciado
        for(int k=0;k<P1.Array.length/2&&op==1;k++){
            System.out.println("Insira um valor para N1:...........");//Enunciado
            value= Integer.parseInt(reader.nextLine());
            P1.Empilhar1(value);
            System.out.println("Deseja continuar:...........");//Enunciado
            op=Integer.parseInt(reader.nextLine());
        }
        System.out.println("==============Pilha 2==============");//Enunciado
        for(int k=P1.Array.length/2;k<P1.Array.length&&op==1;k++){
            System.out.println("Insira um valor para N1:...........");//Enunciado
            value= Integer.parseInt(reader.nextLine());
            P1.Empilhar2(value);
            System.out.println("Deseja continuar:...........");//Enunciado
            op=Integer.parseInt(reader.nextLine());
        }
        
    }
    public static void RemoveDual(PilhaDupla P1){//Procedimento para Remoção nas Plihas 
        System.out.println("========Remocao nas Plihas=========");//Enunciado
    }
    public static void PrintDual(PilhaDupla P1){//Procedimento para Impressão das Plihas 
        
        System.out.println("==========Print de Pilhas==========");//Enunciado
        System.out.println("==============Pilha 1==============");//Enunciado
        P1.Mostrar1();//Impressão da Pliha 1 
        System.out.println("==============Pilha 2==============");//Enunciado
        P1.Mostrar2();//Impressão da Pliha 2
    }
    
    
}
