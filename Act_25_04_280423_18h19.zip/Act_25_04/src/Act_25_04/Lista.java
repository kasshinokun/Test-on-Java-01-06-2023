package Act_25_04;
import java.util.*;
public class Lista {//declaração da classe
    int[] lista;//Vetor de Inteiros para a Lista
    int n=0;//Variavel para analise da Lista
    public Lista(){//Construtor default
        this(5);//Instancia uma Lista de Inteiros de tamanho 5
    }
    public Lista(int tamanho){//Sobrecarga
    	lista =new int[tamanho];
    }
    //Metodos colocados como private para visiveis apenas para a classe
    public void ImprimirArray() {
    	for(int i=0;i<n;i++) {
            System.out.println("item 0"+(i+1)+":"+lista[i]);
    	}
    }
    private void InserirInicio(int k){//Adição de Inteiros no inicio do vetor
        if(n>=lista.length){//Se n igual ou maior que o tamanho da lista....
            //Informa ao Usuario
            System.out.println("\n========Nao e possivel========");
            System.out.println("========inserir dados,========");
            System.out.println("========Lista Cheia===========\n");
        }else{//senao....
            for(int i=n;i>0;i--) {
                lista[i]=lista[i-1];//Move os Inteiros para o fim
            }
            lista[0]=k;//Atribui o valor de k a posição 0
            n++;//incrementa N
        }
    
    }
    private void InserirFim(int k){//Adição de Inteiros no fim do vetor
        if(n>=lista.length){//Se n igual ou maior que o tamanho da lista....
            //Informa ao Usuario
            System.out.println("\n========Nao e possivel========");
            System.out.println("========inserir dados,========");
            System.out.println("========Lista Cheia===========\n");
        }else{//senao....
            lista[n]=k;//Atribui o valor de k a posição na lista
            n++;//incrementa N
        }
    
    }
    private void InserirPosicao(int k,int pos) {
    	//Inserção de Inteiros na posição designada do vetor
    	
    	if(n>=lista.length||pos<0||pos>n){
            //Se n igual ou maior que o tamanho da lista....
            //Ou também se pos menor que 0.... 
            //Ou pos maior que n..... 

            //Informa ao Usuario
            System.out.println("\n========Nao e possivel========");
            System.out.println("========inserir dados,========");
            System.out.println("====Parametros Invalidos !!===\n");
        }else{//senao....
            for(int i=n;i>pos;i--) {
                lista[i]=lista[i-1];
                //Move os Inteiros para o fim
                //(Baseado na posição designada)
            }
            lista[pos]=k;//Atribui o valor de k a posição 0
            n++;//incrementa N
        }
    }
    public void adicionar(int j, int k, int l) {
        if(j==1) {
            InserirInicio(k);
            InserirInicio(l);
        }
        if(j==2) {
            InserirFim(k);
            InserirFim(l);
        }
    }
    public void adicionar2(int k, int l, int pos) {
    	InserirPosicao(k,pos);
    	InserirPosicao(l,pos+1);
    }
    private int RemoverPosicao(int pos) {
    	//Remoção de Strings na posição designada do vetor
    	
    	if(n==0||pos<0||pos>=n){
            //Se n igual a 0....
            //Ou também se pos menor que 0.... 
            //Ou pos maior ou igual a n..... 

            //Informa ao Usuario
            System.out.println("\n========Nao e possivel========");
            System.out.println("========Remover dados,========");
            System.out.println("====Parametros Invalidos !!===\n");
            return -1;
        }else{//senao....
            int resp=lista[pos];//Atribui String na posição designada a resp
            n--;//decrementa N
            for(int i=pos;i<n;i++) {
                lista[i]=lista[i+1];
                //Move as strings para o inicio
                //(Baseado na posição designada)
            }
            return resp;//Retorna a resp ao Main
        }
    }
    public Lista retorna_Lista(Lista L1,int nodo){
    
        int resp=RemoverPosicao(nodo);
        
        System.out.println(resp);
        
        return L1;
    }
    public void L_Inverter(Lista L1){
        
        for (int i = 0, j = n - 1; i < j; i++, j--) {
            int temp = lista[i];
            lista[i] = lista[j];
            lista[j] = temp;
        }
    }
    
}
