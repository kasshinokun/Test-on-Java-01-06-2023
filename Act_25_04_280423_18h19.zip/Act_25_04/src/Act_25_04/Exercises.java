package Act_25_04;
import java.util.*;
public class Exercises {
    //Variavel global para entrada do teclado
    public static Scanner reader = new Scanner(System.in);
    public static void Exercise_1(Lista L1) {

        System.out.println("\n=====01 - Insercao de valores em Lista=====\n");//Enunciado
        System.out.println("Insira um valor para N1:...........");//Enunciado
        int n1 = Integer.parseInt(reader.nextLine());
        System.out.println("Insira um valor para N2:...........");//Enunciado
        int n2= Integer.parseInt(reader.nextLine());
        System.out.println("Voce digitou: "+n1+" e "+n2);
        System.out.println("\nAgora escolha abaixo uma opcao de Insercao:\n");//Enunciado
        int op=0;
        do {
            System.out.println("\n1) Insercao no Inicio\n");//Enunciado
            System.out.println("\n2) Insercao no Fim\n");//Enunciado
            System.out.println("\n3) Insercao na Posição\n");//Enunciado
            op=Integer.parseInt(reader.nextLine());
            switch(op){//Analise do que foi digitado
                //Chama o procedimento
                case 1:
                    L1.adicionar(op, n1, n2);
                    break;
                case 2:
                    L1.adicionar(op, n1, n2);
                    break;
                case 3:
                    System.out.println("\nEscolha a posição desejada:\n");//Enunciado
                    int value= Integer.parseInt(reader.nextLine());
                    L1.adicionar2(n1, n2, value);
                    break;
                default:

            }

        }while(op<1||op>3);
        L1.ImprimirArray();
        System.out.println("\n=========Retornando ao Menu Inicial========\n");//Enunciado
    }
    public static void Exercise_2(Lista L1) {
        System.out.println("\n===02 - Remocao de valor em Lista e Retorno\n");//Enunciado
        System.out.println("Insira um valor desejado:...........");//Enunciado
        int nodo=Integer.parseInt(reader.nextLine());
        L1.retorna_Lista(L1,nodo);
        L1.ImprimirArray();
        System.out.println("\n=========Retornando ao Menu Inicial========\n");//Enunciado
    }
    public static void Exercise_3(Lista L1) {
        System.out.println("\n===03 - Valores em Posicao Inversa na Lista\n");//Enunciado
        System.out.println("Antes de Inverter a Lista");//Enunciado
        L1.ImprimirArray();
        L1.L_Inverter(L1);
        System.out.println("Apos de Inverter a Lista");//Enunciado
        L1.ImprimirArray();
        System.out.println("\n=========Retornando ao Menu Inicial========\n");//Enunciado
        
    }
    public static void Exercise_4(PilhaDupla P1) {
        PilhaDupla.main(P1);
    }
    public static void Exercise_5(Pilha P1,Pilha P2) {
            System.out.println("\n===05 - Insercao de valores em Pilhas======\n");//Enunciado
            System.out.println("Insira valores para Pilhas:...........");//Enunciado
            int value= Integer.parseInt(reader.nextLine());
            if(value>=0){
                //Procedimento de Inserção
                //P1.Add();
                P1.Exibir_Pilha();//Positivos
            }else{
                //Procedimento de Inserção
                //P2.Add();
                P2.Exibir_Pilha();//Negativos
            }
            System.out.println("\n=========Retornando ao Menu Inicial========\n");//Enunciado
    }
    public static void Exercise_6(Fila F,Fila F_Impares, Fila F_Pares) {
            System.out.println("\n===06 -Gestao e Insercao de valores em Filas\n");//Enunciado
            System.out.println("Insira os valores para F:...........");//Enunciado
            int value= Integer.parseInt(reader.nextLine());
            //Procedimento de Inserção
            //F.Add();
            if(value%2==0){
                //Procedimento de Inserção
                //F_Pares.Add();Valores Pares
            }else{
                //Procedimento de Inserção
                //F_Impares.Add();Valores Impares
            }
            F.Exibir_Filas(F, F_Impares, F_Pares);//Exibe as Filas
            System.out.println("\n=========Retornando ao Menu Inicial========\n");//Enunciado
    }
    public static void Exercise_7() {
            System.out.println("\n=====01 - Insercao de valores em Lista=====\n");//Enunciado
            System.out.println("Insira um valor para N1:...........");//Enunciado
            System.out.println("Insira um valor para N2:...........");//Enunciado
            System.out.println("\n=========Retornando ao Menu Inicial========\n");//Enunciado
    }
    public static void Exercise_8() {
            System.out.println("\n=====01 - Insercao de valores em Lista=====\n");//Enunciado
            System.out.println("Insira um valor para N1:...........");//Enunciado
            System.out.println("Insira um valor para N2:...........");//Enunciado
            System.out.println("\n=========Retornando ao Menu Inicial========\n");//Enunciado
    }
    public static void Exercise_9() {
            System.out.println("\n=====01 - Insercao de valores em Lista=====\n");//Enunciado
            System.out.println("Insira um valor para N1:...........");//Enunciado
            System.out.println("Insira um valor para N2:...........");//Enunciado
            System.out.println("\n=========Retornando ao Menu Inicial========\n");//Enunciado
    }
    public static void Exercise_10() {
            System.out.println("\n=====01 - Insercao de valores em Lista=====\n");//Enunciado
            System.out.println("Insira um valor para N1:...........");//Enunciado
            System.out.println("Insira um valor para N2:...........");//Enunciado
            System.out.println("\n=========Retornando ao Menu Inicial========\n");//Enunciado
    }
}
