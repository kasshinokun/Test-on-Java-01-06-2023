package Act_25_04;
import java.util.*;
public class Fila {
    String[] fila;//Vetor de Strings para a Fila
    int[] fila2;//Vetor de Inteiros para a Fila
    int P=0;//Variavel para posição Inicial da Fila
    int U=0;//Variavel para posição Final da Fila
    public Fila() {//Construtor Default
        fila=new String[5];//Para Strings
        fila2=new int[5];//Para Inteiros
    }
    public Fila(int tamanho) {//Sobrecarga
        fila=new String[tamanho+1];//Para Strings
        fila2=new int[tamanho+1];//Para Inteiros
    }
    /*
    public void Add(){Procedimento de Inserção

    }
    */
    public void Exibir_Filas(Fila fila1, Fila fila2, Fila fila3){
    
    }
}
